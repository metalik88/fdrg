package com.vitlmet.discounthunter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.content.SharedPreferences;

import org.json.JSONArray;

public class ReminderReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "discount_reminders";
    private static final String PREFS = "discount_prefs";
    private static final String KEY_ITEMS = "items";

    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String data = prefs.getString(KEY_ITEMS, "[]");

        int count = 0;
        try {
            count = new JSONArray(data).length();
        } catch (Exception ignored) {}

        if (count == 0) {
            return;
        }

        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (manager == null) {
            return;
        }

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Напоминания о скидках",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            manager.createNotificationChannel(channel);
        }

        Intent openApp = new Intent(context, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                100,
                openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String text = "В списке товаров: " + count + ". Проверь Ozon, WB и Маркет.";

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);

        Notification notification = builder
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Пора проверить скидки")
                .setContentText(text)
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .build();

        manager.notify(777, notification);
    }
}
