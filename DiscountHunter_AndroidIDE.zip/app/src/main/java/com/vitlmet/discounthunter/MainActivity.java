package com.vitlmet.discounthunter;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;

public class MainActivity extends Activity {

    private static final String PREFS = "discount_prefs";
    private static final String KEY_ITEMS = "items";
    private static final String KEY_REMINDER = "reminder_enabled";

    private SharedPreferences prefs;
    private EditText queryInput;
    private EditText priceInput;
    private LinearLayout listContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        requestNotificationPermission();

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.setBackgroundResource(getColorResId("bg"));
        scroll.addView(root);

        TextView title = makeText("Охотник за скидками", 28, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = makeText("Добавляй товар, цену и быстро проверяй Ozon, Wildberries и Яндекс.Маркет.", 15, false);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(8), 0, dp(16));
        root.addView(subtitle, matchWrap());

        LinearLayout card = makeCard();
        root.addView(card, matchWrapWithBottom(16));

        queryInput = new EditText(this);
        queryInput.setHint("Что ищем? Например: Yokohama 215/65 R16");
        queryInput.setSingleLine(false);
        queryInput.setMinLines(1);
        queryInput.setTextColor(getColorValue("text_main"));
        queryInput.setHintTextColor(getColorValue("text_second"));
        card.addView(queryInput, matchWrapWithBottom(10));

        priceInput = new EditText(this);
        priceInput.setHint("Максимальная цена, ₽");
        priceInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        priceInput.setTextColor(getColorValue("text_main"));
        priceInput.setHintTextColor(getColorValue("text_second"));
        card.addView(priceInput, matchWrapWithBottom(14));

        Button addButton = makeButton("Добавить в список");
        addButton.setOnClickListener(v -> addItem());
        card.addView(addButton, matchWrapWithBottom(10));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(row1, matchWrapWithBottom(10));

        Button ozon = makeButton("Ozon");
        ozon.setOnClickListener(v -> openSearch("ozon", queryInput.getText().toString()));
        row1.addView(ozon, weightButton());

        Button wb = makeButton("WB");
        wb.setOnClickListener(v -> openSearch("wb", queryInput.getText().toString()));
        row1.addView(wb, weightButton());

        Button market = makeButton("Маркет");
        market.setOnClickListener(v -> openSearch("market", queryInput.getText().toString()));
        row1.addView(market, weightButton());

        Button reminderButton = makeButton(
                prefs.getBoolean(KEY_REMINDER, false)
                        ? "Уведомления включены — нажми, чтобы выключить"
                        : "Напоминать проверять скидки каждые 6 часов"
        );
        reminderButton.setOnClickListener(v -> toggleReminder(reminderButton));
        root.addView(reminderButton, matchWrapWithBottom(16));

        TextView listTitle = makeText("Мой список отслеживания", 22, true);
        root.addView(listTitle, matchWrapWithBottom(10));

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(listContainer, matchWrap());

        setContentView(scroll);
        renderList();
    }

    private void addItem() {
        String query = queryInput.getText().toString().trim();
        String price = priceInput.getText().toString().trim();

        if (query.isEmpty()) {
            Toast.makeText(this, "Введи название товара", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            JSONArray arr = getItems();
            JSONObject obj = new JSONObject();
            obj.put("query", query);
            obj.put("price", price);
            arr.put(obj);
            prefs.edit().putString(KEY_ITEMS, arr.toString()).apply();

            queryInput.setText("");
            priceInput.setText("");
            renderList();
            Toast.makeText(this, "Добавлено", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка добавления", Toast.LENGTH_SHORT).show();
        }
    }

    private void renderList() {
        listContainer.removeAllViews();

        try {
            JSONArray arr = getItems();

            if (arr.length() == 0) {
                TextView empty = makeText("Пока пусто. Добавь товар выше.", 15, false);
                empty.setPadding(0, dp(8), 0, dp(8));
                listContainer.addView(empty, matchWrap());
                return;
            }

            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String query = obj.optString("query");
                String price = obj.optString("price");
                int index = i;

                LinearLayout itemCard = makeCard();
                listContainer.addView(itemCard, matchWrapWithBottom(12));

                TextView name = makeText(query, 18, true);
                itemCard.addView(name, matchWrapWithBottom(4));

                String priceLine = price.isEmpty() ? "Цена не указана" : "Ищем дешевле: " + price + " ₽";
                TextView priceText = makeText(priceLine, 14, false);
                itemCard.addView(priceText, matchWrapWithBottom(12));

                Button all = makeButton("Открыть поиск везде");
                all.setOnClickListener(v -> {
                    openSearch("ozon", query);
                    openSearch("wb", query);
                    openSearch("market", query);
                });
                itemCard.addView(all, matchWrapWithBottom(8));

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                itemCard.addView(row, matchWrapWithBottom(8));

                Button b1 = makeButton("Ozon");
                b1.setOnClickListener(v -> openSearch("ozon", query));
                row.addView(b1, weightButton());

                Button b2 = makeButton("WB");
                b2.setOnClickListener(v -> openSearch("wb", query));
                row.addView(b2, weightButton());

                Button b3 = makeButton("Маркет");
                b3.setOnClickListener(v -> openSearch("market", query));
                row.addView(b3, weightButton());

                Button delete = makeButton("Удалить");
                delete.setOnClickListener(v -> deleteItem(index));
                itemCard.addView(delete, matchWrap());
            }

        } catch (Exception e) {
            TextView error = makeText("Ошибка чтения списка", 15, false);
            listContainer.addView(error, matchWrap());
        }
    }

    private void deleteItem(int index) {
        try {
            JSONArray old = getItems();
            JSONArray fresh = new JSONArray();

            for (int i = 0; i < old.length(); i++) {
                if (i != index) {
                    fresh.put(old.getJSONObject(i));
                }
            }

            prefs.edit().putString(KEY_ITEMS, fresh.toString()).apply();
            renderList();
            Toast.makeText(this, "Удалено", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка удаления", Toast.LENGTH_SHORT).show();
        }
    }

    private JSONArray getItems() {
        try {
            return new JSONArray(prefs.getString(KEY_ITEMS, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void openSearch(String source, String rawQuery) {
        String query = rawQuery.trim();
        if (query.isEmpty()) {
            Toast.makeText(this, "Сначала введи товар", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            String encoded = URLEncoder.encode(query, "UTF-8");
            String url;

            if ("ozon".equals(source)) {
                url = "https://www.ozon.ru/search/?text=" + encoded;
            } else if ("wb".equals(source)) {
                url = "https://www.wildberries.ru/catalog/0/search.aspx?search=" + encoded;
            } else {
                url = "https://market.yandex.ru/search?text=" + encoded;
            }

            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось открыть поиск", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleReminder(Button button) {
        boolean enabled = prefs.getBoolean(KEY_REMINDER, false);

        if (enabled) {
            cancelReminder();
            prefs.edit().putBoolean(KEY_REMINDER, false).apply();
            button.setText("Напоминать проверять скидки каждые 6 часов");
            Toast.makeText(this, "Уведомления выключены", Toast.LENGTH_SHORT).show();
        } else {
            scheduleReminder(this);
            prefs.edit().putBoolean(KEY_REMINDER, true).apply();
            button.setText("Уведомления включены — нажми, чтобы выключить");
            Toast.makeText(this, "Уведомления включены", Toast.LENGTH_SHORT).show();
        }
    }

    public static void scheduleReminder(Context context) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                context,
                777,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        long firstStart = System.currentTimeMillis() + 10 * 60 * 1000;
        long interval = 6 * 60 * 60 * 1000;

        if (alarm != null) {
            alarm.setInexactRepeating(
                    AlarmManager.RTC_WAKEUP,
                    firstStart,
                    interval,
                    pi
            );
        }
    }

    private void cancelReminder() {
        Intent intent = new Intent(this, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                this,
                777,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) {
            alarm.cancel(pi);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
    }

    private LinearLayout makeCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackgroundResource(getDrawableResId("card_bg"));
        return card;
    }

    private TextView makeText(String text, int sp, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(getColorValue("text_main"));
        if (bold) {
            tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }
        return tv;
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundResource(getDrawableResId("button_bg"));
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private LinearLayout.LayoutParams matchWrapWithBottom(int bottomDp) {
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(0, 0, 0, dp(bottomDp));
        return lp;
    }

    private LinearLayout.LayoutParams weightButton() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1
        );
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private int getColorValue(String name) {
        return getResources().getColor(getColorResId(name));
    }

    private int getColorResId(String name) {
        return getResources().getIdentifier(name, "color", getPackageName());
    }

    private int getDrawableResId(String name) {
        return getResources().getIdentifier(name, "drawable", getPackageName());
    }
}
